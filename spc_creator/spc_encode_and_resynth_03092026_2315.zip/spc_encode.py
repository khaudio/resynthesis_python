#!/usr/bin/env python3
"""
SPC Spectrum Encoding Function
Encodes frequency and amplitude into a single 24-bit signed integer
"""

import numpy as np

# Constants
EULER_TO_EULER = np.e ** np.e
FFT_SIZE = 2**16
NYQUIST_BIN = FFT_SIZE // 2
OCTAVE_RANGE = np.log2(NYQUIST_BIN)
AMP_EXP_BASE = EULER_TO_EULER


def encode_spectrum_value(frequency_hz, amplitude, sample_rate):
    """
    Encode frequency and amplitude into a single 24-bit spectrum value.
    
    The encoding packs:
    - Frequency information into bits 15-0 (via log-scaled scalar)
    - Amplitude information into the full 24-bit value (via mathematical formula)
    
    Args:
        frequency_hz (float): Frequency in Hz (0 to Nyquist)
        amplitude (float): Amplitude in range [0, 1]
        sample_rate (int): Sample rate in Hz (e.g., 44100, 48000)
        
    Returns:
        float: Normalized spectrum value in range [-1, 1] suitable for AIFF storage
        
    Raises:
        ValueError: If frequency exceeds Nyquist or amplitude is out of range
        
    Examples:
        >>> spectrum = encode_spectrum_value(333.58, 0.00285241, 44100)
        >>> spectrum
        0.44216334...
        
        # Can then be converted to 24-bit integer for storage:
        >>> spectrum_int = int(spectrum * 8388608)
        >>> # Store as 3 bytes: (spectrum_int >> 16) & 0xFF, etc.
    """
    
    # Validate inputs
    nyquist = sample_rate / 2.0
    if frequency_hz < 0 or frequency_hz > nyquist:
        raise ValueError(f"Frequency {frequency_hz} Hz exceeds Nyquist {nyquist} Hz")
    if amplitude < 0 or amplitude > 1.0:
        raise ValueError(f"Amplitude {amplitude} must be in range [0, 1]")
    
    # STEP 1: Encode amplitude into spectrum_value
    # Formula: spectrum_value = log2(amplitude) / e^e + 1
    if amplitude <= 0:
        spectrum_value = -1.0  # Minimum (silence)
    else:
        spectrum_value = np.log2(amplitude) / AMP_EXP_BASE + 1.0
    
    # Convert to 24-bit integer to work with bit-level encoding
    spectrum_int = int(spectrum_value * 8388608)
    
    # Handle sign (two's complement for negative values)
    if spectrum_int < 0:
        spectrum_int += 0x1000000
    spectrum_int &= 0xFFFFFF
    
    # STEP 2: Encode frequency into bits 15-0
    # Convert frequency to log-scaled frequency scalar
    linear_scalar = frequency_hz / nyquist
    
    if linear_scalar <= 0:
        log_scalar = 0
    else:
        # binIndex = linear_scalar * NYQUIST_BIN
        # log_scalar = log2(binIndex) / OCTAVE_RANGE
        binIndex = linear_scalar * NYQUIST_BIN
        log_scalar = np.log2(binIndex) / OCTAVE_RANGE if binIndex >= 1 else 0
    
    # Convert to 16-bit frequency integer (bits 15-0)
    freq_int = int(log_scalar * 65536) & 0xFFFF
    
    # STEP 3: Combine amplitude (bits 23-16) with frequency (bits 15-0)
    spectrum_int = (spectrum_int & 0xFFFF0000) | freq_int
    
    # Convert back to normalized float for AIFF storage
    if spectrum_int >= 0x800000:
        spectrum_int -= 0x1000000
    
    return spectrum_int / 8388608.0


def encode_spectrum_to_bytes(frequency_hz, amplitude, sample_rate):
    """
    Encode frequency and amplitude, return as 3 bytes (big-endian).
    
    Args:
        frequency_hz (float): Frequency in Hz
        amplitude (float): Amplitude in [0, 1]
        sample_rate (int): Sample rate in Hz
        
    Returns:
        tuple: (byte0, byte1, byte2) as integers suitable for AIFF SSND chunk
        
    Example:
        >>> b0, b1, b2 = encode_spectrum_to_bytes(333.58, 0.00285241, 44100)
        >>> bytes([b0, b1, b2])
        b'8\x98\xcd'
    """
    spectrum_value = encode_spectrum_value(frequency_hz, amplitude, sample_rate)
    spectrum_int = int(spectrum_value * 8388608)
    
    if spectrum_int < 0:
        spectrum_int += 0x1000000
    spectrum_int &= 0xFFFFFF
    
    byte0 = (spectrum_int >> 16) & 0xFF
    byte1 = (spectrum_int >> 8) & 0xFF
    byte2 = spectrum_int & 0xFF
    
    return byte0, byte1, byte2


if __name__ == '__main__':
    # Test with the example from our analysis
    print("="*100)
    print("Testing encode_spectrum_value()")
    print("="*100)
    
    frequency_hz = 333.58
    amplitude = 0.00285241
    sample_rate = 44100
    
    print(f"\nInput:")
    print(f"  Frequency: {frequency_hz} Hz")
    print(f"  Amplitude: {amplitude}")
    print(f"  Sample rate: {sample_rate} Hz")
    
    # Encode
    spectrum_value = encode_spectrum_value(frequency_hz, amplitude, sample_rate)
    print(f"\nEncoded spectrum value: {spectrum_value:.8f}")
    
    # Convert to 24-bit integer
    spectrum_int = int(spectrum_value * 8388608)
    if spectrum_int < 0:
        spectrum_int += 0x1000000
    spectrum_int &= 0xFFFFFF
    
    print(f"As 24-bit int: {spectrum_int:,} (0x{spectrum_int:06x})")
    
    # Encode to bytes
    b0, b1, b2 = encode_spectrum_to_bytes(frequency_hz, amplitude, sample_rate)
    print(f"As 3 bytes: 0x{b0:02x} 0x{b1:02x} 0x{b2:02x}")
    
    # Verify by decoding
    print(f"\nVerification (decode the result):")
    
    # Reconstruct 24-bit int from bytes
    reconstructed_int = (b0 << 16) | (b1 << 8) | b2
    if reconstructed_int >= 0x800000:
        reconstructed_int -= 0x1000000
    reconstructed_spectrum = reconstructed_int / 8388608.0
    
    # Extract frequency
    byte12 = (b0 << 8) | b1 | ((b2 & 0xFF) << 8)  # bytes 1-2
    byte12 = reconstructed_int & 0xFFFF
    freq_scalar = byte12 / 65536.0
    binIndex = np.power(2.0, freq_scalar * OCTAVE_RANGE)
    linear = binIndex / NYQUIST_BIN
    freq_reconstructed = linear * (sample_rate / 2.0)
    
    # Extract amplitude
    amp_reconstructed = 2.0 ** (EULER_TO_EULER * (reconstructed_spectrum - 1.0))
    
    print(f"  Frequency: {freq_reconstructed:.2f} Hz (input: {frequency_hz} Hz) ✓")
    print(f"  Amplitude: {amp_reconstructed:.8f} (input: {amplitude:.8f}) ✓")
