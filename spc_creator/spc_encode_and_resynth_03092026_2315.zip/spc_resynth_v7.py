#!/usr/bin/env python3
"""
spc_resynth_v7: Pure v3 structure with current best formulas
- Original sequential processing loop from v3
- Amplitude: 2^(e^e * (spectrum - 1))
- 128 partials per frame (124 "true" + 4 tails)
"""

import struct
import numpy as np
from scipy.io import wavfile

# Constants
fftSize = np.power(2, 16)
nyquistBin = fftSize // 2
octaveRange = np.log2(nyquistBin)
tau = 2 * np.pi

# Amplitude formula constants
EULER_TO_EULER = np.e ** np.e
AMP_EXP_BASE = EULER_TO_EULER


def load_aiff_mono_correct(filename):
    """Load 24-bit AIFF file, respecting SSND chunk size."""
    with open(filename, 'rb') as f:
        data = f.read()
    
    ssnd_pos = data.find(b'SSND')
    chunk_size = struct.unpack('>I', data[ssnd_pos+4:ssnd_pos+8])[0]
    ssnd_data_start = ssnd_pos + 16
    
    num_samples = (chunk_size - 8) // 3
    
    samples = []
    for i in range(num_samples):
        offset = ssnd_data_start + (i * 3)
        b0, b1, b2 = data[offset], data[offset+1], data[offset+2]
        val = (b0 << 16) | (b1 << 8) | b2
        if val >= 0x800000:
            val = val - 0x1000000
        samples.append(val / 0x800000)
    
    return np.array(samples, dtype=np.float64)


class Oscillator:
    def __init__(self, samplerate, frequency, amplitude=1.0, radians=0.0):
        self.__frequency = 0.0
        self.__amplitude = 1.0
        self.sampleRate = samplerate
        self.frequency = frequency
        self.amplitude = amplitude
        self.radians = radians

    @property
    def amplitude(self):
        return self.__amplitude

    @amplitude.setter
    def amplitude(self, amplitude):
        if amplitude < 0:
            raise ValueError('Amplitude must be greater than 0.0')
        self.__amplitude = amplitude

    @property
    def sampleRate(self):
        return self.__sampleRate

    @sampleRate.setter
    def sampleRate(self, samplerate):
        self.__sampleRate = samplerate
        self.increment = tau * self.frequency / samplerate
    
    @property
    def frequency(self):
        return self.__frequency

    @frequency.setter
    def frequency(self, frequency):
        self.__frequency = frequency
        self.increment = tau * self.__frequency / self.sampleRate

    def __call__(self, numSamples):
        if self.frequency == 0.0:
            return np.zeros(numSamples)
        n = np.arange(numSamples)
        samples = (self.amplitude * np.sin(self.radians + n * self.increment))
        self.radians += (self.increment * numSamples)
        self.radians %= tau
        return samples


class OscillatorBank:
    def __init__(self, sampleRate, numOscillators):
        self.sampleRate = sampleRate
        self.numOscillators = numOscillators
        self.oscillators = []
        for i in range(numOscillators):
            self.oscillators.append(Oscillator(sampleRate, frequency=0, amplitude=0))

    def get_osc_sum(self, numSamples):
        return np.sum([oscillator(numSamples) for oscillator in self.oscillators], axis=0)


def extract_frequency_scalar(spectrum_value):
    """Extract frequency scalar from bytes 1-2 of spectrum value."""
    spectrum_int = int(spectrum_value * 8388608)
    if spectrum_int < 0:
        spectrum_int += 0x1000000
    spectrum_int &= 0xFFFFFF
    
    byte12 = spectrum_int & 0xFFFF
    return byte12 / 65536.0


def log_freq_scalar_to_linear(logValue):
    """Convert log-scaled frequency scalar to linear scalar."""
    binIndex = np.power(2.0, (logValue * octaveRange))
    if (binIndex < 1) or (logValue <= 0.0):
        return 0
    return (binIndex / nyquistBin)


def get_frequency_from_linear_scalar(linearValue, sampleRate):
    """Convert linear scalar to frequency in Hz."""
    return linearValue * (sampleRate * 0.5)


def extract_amplitude(spectrum_value):
    """Extract amplitude using formula: 2^(e^e * (spectrum - 1))"""
    return 2.0 ** (AMP_EXP_BASE * (spectrum_value - 1.0))


def increment_partial_index(partialIndex, numPartials):
    """Wrap around partial index."""
    return (partialIndex + 1) % numPartials


def main():
    spc_file = '/mnt/user-data/uploads/carla_iam_spc_data_trimmed.aif'
    output_file = '/mnt/user-data/outputs/spc_resynth_v7.wav'
    sampleRate = 44100
    
    print("="*100)
    print("spc_resynth_v7: Original v3 structure with e^e amplitude formula")
    print("="*100)
    print(f"\nFormula: amplitude = 2^(e^e * (spectrum - 1))")
    print(f"         where e^e = {AMP_EXP_BASE:.8f}")
    
    print(f"\nLoading SPC data...", end=" ", flush=True)
    spc_data = load_aiff_mono_correct(spc_file)
    print(f"({len(spc_data):,} samples)")
    
    numPartials = 128
    outputBuff = np.array([], dtype=np.float64)
    partialIndex = 0
    oscBank = OscillatorBank(sampleRate=sampleRate, numOscillators=numPartials)
    
    print(f"\nSynthesizing...", end=" ", flush=True)
    
    for idx, spectrum_val in enumerate(spc_data):
        # Frequency from SPC
        freq_scalar = extract_frequency_scalar(spectrum_val)
        freq_scalar = log_freq_scalar_to_linear(freq_scalar)
        freq_hz = get_frequency_from_linear_scalar(freq_scalar, sampleRate)
        
        # Amplitude from formula
        amp_scalar = extract_amplitude(spectrum_val)
        
        oscBank.oscillators[partialIndex].amplitude = amp_scalar
        oscBank.oscillators[partialIndex].frequency = freq_hz
        
        outputBuff = np.append(outputBuff, oscBank.get_osc_sum(1))
        partialIndex = increment_partial_index(partialIndex, numPartials)
        
        if (idx + 1) % 10000 == 0:
            print(f"\n  {idx + 1}/{len(spc_data)}", end=" ", flush=True)
    
    print()
    
    print(f"\nAmplitude statistics:")
    print(f"  Peak: {np.max(np.abs(outputBuff)):.6f}")
    print(f"  RMS: {np.sqrt(np.mean(outputBuff**2)):.6f}")
    
    print(f"\nWriting file...", end=" ", flush=True)
    wavfile.write(output_file, sampleRate,
                  (np.clip(outputBuff, -1.0, 1.0) * 32767).astype(np.int16))
    print(f"({len(outputBuff):,} samples)")
    
    print(f"\n✓ {output_file}")


if __name__ == '__main__':
    main()
