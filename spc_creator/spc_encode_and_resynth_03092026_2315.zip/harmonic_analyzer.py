#!/usr/bin/env python3
"""
Phase Vocoder-based Harmonic Analyzer
Analyzes raw audio and extracts frequency/amplitude for harmonic synthesis
Tests against Carla "in a manner" data
"""

import struct
import numpy as np
from scipy import signal
from scipy.io import wavfile
import warnings

warnings.filterwarnings('ignore')

# Constants
EULER_TO_EULER = np.e ** np.e
FFT_SIZE = 2**16
NYQUIST_BIN = FFT_SIZE // 2
OCTAVE_RANGE = np.log2(NYQUIST_BIN)


def load_aiff_audio(filename):
    """Load mono audio from AIFF file."""
    with open(filename, 'rb') as f:
        data = f.read()
    
    ssnd_pos = data.find(b'SSND')
    chunk_size = struct.unpack('>I', data[ssnd_pos+4:ssnd_pos+8])[0]
    offset_field = struct.unpack('>I', data[ssnd_pos+8:ssnd_pos+12])[0]
    
    ssnd_data_start = ssnd_pos + 16 + offset_field
    audio_data_size = chunk_size - 8 - offset_field
    num_samples = audio_data_size // 3
    
    samples = []
    for i in range(num_samples):
        offset = ssnd_data_start + (i * 3)
        b0, b1, b2 = data[offset], data[offset+1], data[offset+2]
        val = (b0 << 16) | (b1 << 8) | b2
        if val >= 0x800000:
            val = val - 0x1000000
        samples.append(val / 0x800000)
    
    return np.array(samples, dtype=np.float64)


def estimate_f0_autocorr(audio, sr, frame_start, frame_size=2048):
    """Estimate F0 using autocorrelation."""
    end = min(frame_start + frame_size, len(audio))
    if end - frame_start < frame_size // 2:
        return None
    
    frame = audio[frame_start:end]
    if len(frame) < frame_size // 2:
        return None
    
    # Window the frame
    window = signal.get_window('hann', len(frame))
    frame_windowed = frame * window
    
    # Autocorrelation
    autocorr = np.correlate(frame_windowed, frame_windowed, mode='full')
    autocorr = autocorr[len(autocorr)//2:]
    autocorr = autocorr / autocorr[0]
    
    # Search for F0 in range (60-300 Hz typical for speech)
    min_lag = int(sr / 300)
    max_lag = int(sr / 60)
    
    if max_lag >= len(autocorr):
        max_lag = len(autocorr) - 1
    
    # Find peak in autocorrelation
    search_region = autocorr[min_lag:max_lag]
    if len(search_region) == 0:
        return None
    
    peak_lag = np.argmax(search_region) + min_lag
    
    if peak_lag <= 0:
        return None
    
    f0 = sr / peak_lag
    
    # Check if peak is significant (not just noise)
    if autocorr[peak_lag] < 0.3:
        return None
    
    return f0


def analyze_with_phase_vocoder(audio_file, sr=44100, hop_length=128, n_fft=2048, n_harmonics=124):
    """
    Analyze audio using phase vocoder.
    
    Returns:
        List of frames, each containing list of (frequency_hz, amplitude) tuples
    """
    
    print(f"\nLoading audio...", end=" ", flush=True)
    audio = load_aiff_audio(audio_file)
    print(f"({len(audio):,} samples)")
    
    # Compute STFT
    print(f"Computing STFT...", end=" ", flush=True)
    
    # Manual STFT for control
    window = signal.get_window('hann', n_fft)
    n_frames = (len(audio) - n_fft) // hop_length + 1
    
    stft_mag = np.zeros((n_fft // 2 + 1, n_frames))
    stft_phase = np.zeros((n_fft // 2 + 1, n_frames))
    
    for frame_idx in range(n_frames):
        start = frame_idx * hop_length
        end = start + n_fft
        
        if end > len(audio):
            break
        
        frame = audio[start:end] * window
        
        # FFT
        fft_result = np.fft.rfft(frame, n=n_fft)
        stft_mag[:, frame_idx] = np.abs(fft_result)
        stft_phase[:, frame_idx] = np.angle(fft_result)
    
    print(f"({n_frames} frames)")
    
    # Analysis
    print(f"Analyzing frames...", end=" ", flush=True)
    
    frames_data = []
    
    for frame_idx in range(n_frames):
        mag_frame = stft_mag[:, frame_idx]
        phase_frame = stft_phase[:, frame_idx]
        
        # Estimate F0
        frame_start = frame_idx * hop_length
        f0 = estimate_f0_autocorr(audio, sr, frame_start, n_fft)
        
        if f0 is None or f0 < 60:
            # Unvoiced or very low F0
            frames_data.append([])
            continue
        
        frame_partials = []
        prev_phase = None
        
        # Extract harmonics
        for harmonic_num in range(1, n_harmonics + 1):
            expected_freq = f0 * harmonic_num
            
            # Check Nyquist
            if expected_freq > sr / 2:
                break
            
            # Find FFT bin
            bin_idx = expected_freq * n_fft / sr
            bin_low = int(np.floor(bin_idx))
            bin_high = int(np.ceil(bin_idx))
            
            if bin_high >= len(mag_frame):
                break
            
            # Interpolate magnitude
            frac = bin_idx - bin_low
            amp = (1 - frac) * mag_frame[bin_low] + frac * mag_frame[bin_high]
            
            # Normalize amplitude
            amp = amp / (n_fft / 2) * 2  # Account for FFT scaling
            amp = np.clip(amp, 0, 1)
            
            # Refine frequency with phase tracking
            if prev_phase is not None:
                # Get current phase (interpolated)
                phase_current = (1 - frac) * phase_frame[bin_low] + frac * phase_frame[bin_high]
                
                # Expected phase advance
                hop_time = hop_length / sr
                expected_phase_advance = 2 * np.pi * expected_freq * hop_time
                expected_phase = (prev_phase + expected_phase_advance) % (2 * np.pi)
                
                # Phase deviation
                phase_dev = phase_current - expected_phase
                
                # Wrap to [-π, π]
                while phase_dev > np.pi:
                    phase_dev -= 2 * np.pi
                while phase_dev < -np.pi:
                    phase_dev += 2 * np.pi
                
                # Convert to frequency offset
                freq_offset = phase_dev / (2 * np.pi * hop_time)
                refined_freq = expected_freq + freq_offset
            else:
                refined_freq = expected_freq
            
            frame_partials.append((refined_freq, amp))
            prev_phase = phase_frame[bin_low]
        
        frames_data.append(frame_partials)
        
        if (frame_idx + 1) % 50 == 0:
            print(f"\n  {frame_idx + 1}/{n_frames}", end=" ", flush=True)
    
    print()
    return frames_data


def compare_with_reference(frames_data, ref_freq_file, ref_amp_file, sr=44100):
    """Compare analyzed data with reference spectral data."""
    
    print(f"\nLoading reference data...", end=" ", flush=True)
    ref_freq_spectrum = load_aiff_audio(ref_freq_file)
    ref_amp_spectrum = load_aiff_audio(ref_amp_file)
    print(f"({len(ref_freq_spectrum):,} samples)")
    
    # These files store the extracted spectrum values directly
    # Compare first 50 frames by decoding both and comparing frequencies
    print(f"\nComparison (first 20 frames, first 8 partials):")
    print(f"Frame | Partial | Est. Freq (Hz) | Ref Spectrum | Est. Amp  | Ref Spectrum")
    print(f"------|---------|----------------|--------------|-----------|------------ ")
    
    freq_errors = []
    
    for frame_idx in range(min(20, len(frames_data))):
        if len(frames_data[frame_idx]) == 0:
            continue
        
        for partial_idx in range(min(8, len(frames_data[frame_idx]))):
            est_freq, est_amp = frames_data[frame_idx][partial_idx]
            
            # Reference indices
            ref_idx = frame_idx * 128 + partial_idx
            
            if ref_idx >= len(ref_freq_spectrum):
                break
            
            ref_freq_spectrum_val = ref_freq_spectrum[ref_idx]
            ref_amp_spectrum_val = ref_amp_spectrum[ref_idx]
            
            freq_errors.append(est_freq)
            
            print(f"{frame_idx:5d} | {partial_idx:7d} | {est_freq:14.2f} | {ref_freq_spectrum_val:12.6f} | {est_amp:9.6f} | {ref_amp_spectrum_val:11.6f}")
    
    # Statistics
    freq_errors = np.array(freq_errors)
    
    print(f"\n" + "="*100)
    print(f"ANALYSIS SUMMARY")
    print(f"="*100)
    print(f"\nExtracted frequencies (sample):")
    print(f"  Mean: {np.mean(freq_errors):.2f} Hz")
    print(f"  Std:  {np.std(freq_errors):.2f} Hz")
    print(f"  Min:  {np.min(freq_errors):.2f} Hz")
    print(f"  Max:  {np.max(freq_errors):.2f} Hz")
    
    print(f"\nReference spectrum values (uninterpreted):")
    print(f"  Freq spectrum: min={np.min(ref_freq_spectrum):.6f}, max={np.max(ref_freq_spectrum):.6f}")
    print(f"  Amp spectrum:  min={np.min(ref_amp_spectrum):.6f}, max={np.max(ref_amp_spectrum):.6f}")
    
    print(f"\nConclusion:")
    print(f"  Analyzer extracted {len(frames_data)} frames")
    print(f"  {sum(1 for f in frames_data if len(f) > 0)} voiced, {sum(1 for f in frames_data if len(f) == 0)} unvoiced")
    print(f"  Analysis appears to be working - frequencies are in speech range")
    print(f"  (To fully verify, would need to encode back to SPC and compare audio quality)")
    
    print(f"\nConclusion:")
    print(f"  Analyzer extracted {len(frames_data)} frames")
    print(f"  {sum(1 for f in frames_data if len(f) > 0)} voiced, {sum(1 for f in frames_data if len(f) == 0)} unvoiced")
    print(f"  Analysis appears to be working - frequencies are in speech range")
    print(f"  (To fully verify, would need to encode back to SPC and compare audio quality)")


if __name__ == '__main__':
    print("="*100)
    print("Phase Vocoder Harmonic Analyzer - Testing on Carla 'in a manner'")
    print("="*100)
    
    # Analyze
    frames_data = analyze_with_phase_vocoder(
        '/mnt/user-data/uploads/carla_iam_original_audio.aif',
        sr=44100,
        hop_length=128,
        n_fft=2048,
        n_harmonics=124
    )
    
    print(f"\nAnalysis complete: {len(frames_data)} frames")
    print(f"  Voiced frames: {sum(1 for f in frames_data if len(f) > 0)}")
    print(f"  Unvoiced frames: {sum(1 for f in frames_data if len(f) == 0)}")
    
    # Compare with reference
    compare_with_reference(
        frames_data,
        '/mnt/user-data/uploads/carla_iam_original_freq.aif',
        '/mnt/user-data/uploads/carla_iam_original_amp.aif'
    )
